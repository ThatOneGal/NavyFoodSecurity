<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Create Order')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">


                <form action="<?php echo e(route('order.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div>
                        <h1>Ordering Form</h1>
                    </div>
                    <div> 
                        <div>
                            <label for="Location">Destination:</label>
                        </div>

                        <div>
                            

                            <select name="LocationId" id="LocationId">
                                <?php $__currentLoopData = $locationList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($location->id); ?>"><?php echo e($location->locationName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                    </div>



                    <div> 
                        <div>
                            <label for="CustomerId">Order Recipient</label>
                        </div>

                        <div>
                            <input type="text" id="CustomerId" value="<?php echo e(Auth::user()->id); ?>  " readonly>
                        </div>
                    </div>

                    <div>
                        <div>
                            <label for="Content">Content:</label>
                        </div>

                        <div>
                            <textarea name="Content" id="Content" cols="0" rows="0"></textarea>
                        </div>
                    </div>

                    <div> 
                        <div>
                            <label for="NotesStorage">Notes:</label>
                        </div>
                        <div>
                            <textarea name="NotesStorage" id="NotesStorage" cols="0" rows="0"></textarea>
                        </div>

                    </div>
                    <div>
                        <input type="submit" value="Submit">
                        <input type="reset" value="Cancel">

                    </div>

                </form>


            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH E:\GitHubRepo\NavyFoodSecurity\NavyFoodApp\resources\views/Order/OrderingForm.blade.php ENDPATH**/ ?>