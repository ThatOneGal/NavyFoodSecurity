<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('History')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w17xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">

                <table class="mx-auto">
                    
                    <thead>
                    <tr>
                        <th>Order Id</th>
                        <th>Destination</th>
                        <th>Recipient</th>
                        <th>Status</th>
                        <th>Created</th>
                        <th>Shipped</th>
                        <th class>Packed</th>
                        <th>Packaged Qty</th>
                        <th>Content</th>
                        <th>Notes Storage</th>
                        <th>Notes Preparation</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $orderList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border">
                            <td><label class="col-sm-2" for=""><?php echo e($order->id); ?></label></td>
                            <td>
                                <?php $__currentLoopData = $locationList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($order->LocationId == $location->id): ?>
                                        <?php echo e($location->locationName); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo e($order->CustomerId); ?></td>
                            <td>
                                <?php $__currentLoopData = $statusList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($order->StatusId == $status->id): ?>
                                        <?php echo e($status->statusName); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><?php echo e($order->OrderDate); ?></td>
                            <td>
                                <?php if($order->OrderShipped == null): ?>
                                    0000-00-00 00:00:00
                                <?php else: ?>
                                    <?php echo e($Order->OrderShipped); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($order->OrderPacked == null): ?>
                                    0000-00-00 00:00:00
                                <?php else: ?>
                                    <?php echo e($order->OrderPacked); ?>

                                <?php endif; ?>
                            </td>
                            <td><?php echo e($order->PackageQty); ?></td>
                            <td><?php echo e($order->Content); ?></td>
                            <td><?php echo e($order->NotesStorage); ?></td>
                            <td><?php echo e($order->NotesPreparation); ?></td>
                            <td><a href="<?php echo e(route('order.edit', $order)); ?>">
                                    <button class='button button-primary' type="submit">Edit</button>
                                </a>

                                <form method="POST" action="<?php echo e(route('order.destroy', $order)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class='button button-primary' type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH E:\GitHubRepo\NavyFoodSecurity\NavyFoodApp\resources\views/Order/index.blade.php ENDPATH**/ ?>