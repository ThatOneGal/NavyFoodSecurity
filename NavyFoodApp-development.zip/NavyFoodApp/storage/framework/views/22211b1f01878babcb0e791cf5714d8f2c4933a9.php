<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Order:')); ?> <?php echo e($Order->id); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">

                <div> 
                    <div><label for="Location">Destination:</label></div>
                    <div>
                        <div>
                            <label for="Location">
                                <?php $__currentLoopData = $locationList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($Order->LocationId == $location->id): ?>
                                        <?php echo e($location->locationName); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </label>
                        </div>
                    </div>


                    <div> 
                        <div><label for="Status">Status:</label></div>

                        <div>
                            <label for="Status">
                                <?php $__currentLoopData = $statusList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($Order->StatusId == $status->id): ?>
                                        <?php echo e($status->statusName); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </label>
                        </div>
                    </div>


                    <div> 
                        <div>
                            <label for="OrderDate">Date Ordered:</label>
                        </div>
                        <div>
                            <label for="OrderDate"><?php echo e($Order->OrderDate); ?></label>
                        </div>
                    </div>

                    <div> 
                        <div>
                            <label for="OrderShipped">Date Shipped:</label>
                        </div>
                        <div>
                            <label for="OrderShipped">
                                <?php if($Order->OrderShipped == null): ?>
                                    0000-00-00 00:00:00
                                <?php else: ?>
                                    <?php echo e($Order->OrderShipped); ?>

                                <?php endif; ?> </label>
                        </div>
                    </div>

                    <div> 
                        <div>
                            <label for="OrderPacked">Date Packed:</label>
                        </div>
                        <div>
                            <label for="OrderPacked">
                                <?php if($Order->OrderPacked == null): ?>
                                    0000-00-00 00:00:00
                                <?php else: ?>
                                    <?php echo e($Order->OrderPacked); ?>

                                <?php endif; ?>
                            </label>
                        </div>
                    </div>


                    <div> 
                        <div>
                            <label for="PackageQty">Package Qty:</label>
                        </div>
                        <div>
                            <textarea name="PackageQty" id="PackageQty" cols="0"
                                      rows="0" readonly><?php echo e($Order->PackageQty); ?></textarea>
                        </div>

                    </div>

                    <div> 
                        <div>
                            <label for="CustomerId">Order Recipient</label>
                        </div>

                        <div>
                            <input type="text" id="CustomerId"
                                   value="<?php echo e($Order->CustomerId); ?>  " readonly>
                        </div>
                    </div>


                    <div>
                        <div>
                            <label for="Content">Content:</label>
                        </div>

                        <div>
                            <textarea name="Content" id="Content" cols="0" rows="0"
                                      readonly><?php echo e($Order->Content); ?></textarea>
                        </div>
                    </div>

                    <div> 
                        <div>
                            <label for="NotesStorage">Notes:</label>
                        </div>
                        <div>
                            <textarea name="NotesStorage" id="NotesStorage" cols="0"
                                      rows="0" readonly><?php echo e($Order->NotesStorage); ?></textarea>
                        </div>


                        <div> 
                            <div>
                                <label for="NotesPreparation">Notes Preparation :</label>
                            </div>
                            <div>
                            <textarea name="NotesPreparation" id="NotesPreparation" cols="0"
                                      rows="0" readonly><?php echo e($Order->NotesPreparation); ?></textarea>
                            </div>

                        </div>
                        <a href="<?php echo e(route('order.edit', $Order)); ?>">Edit</a>
                    </div>
                </div>

                <div>
                    <?php echo QrCode::size(500)->format('svg')->generate($Order, public_path('images/qrcode.svg')); ?>

                    <img src="<?php echo e(url('/images/qrcode.svg')); ?>"/>


                </div>

            </div>
        </div>
    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH E:\GitHubRepo\NavyFoodSecurity\NavyFoodApp\resources\views/Order/Show.blade.php ENDPATH**/ ?>